#### 1.	What two things does an object bundle together?

	Data, in the form of fields, and operations on that data, in the form of methods.

#### 2.	True/False. C# lets you define new types of objects.

	True. This is a key part of programming in C#, and the focus of Part 2.