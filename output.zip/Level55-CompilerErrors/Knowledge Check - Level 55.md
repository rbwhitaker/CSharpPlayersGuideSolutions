#### 1. True/False. Your program can still run when it has compiler warnings.

	True. It cannot run with compiler errors, but it can run with compiler warnings. Generally,
	you will want to address these warnings before moving on too far though. They typically
	represent legitimate problems with your code.

#### 2. Name three ways to help work through or reduce tricky or problematic compiler errors. 

	Any of the subsection headings under _How to Resolve Compiler Errors_ are good answers.

