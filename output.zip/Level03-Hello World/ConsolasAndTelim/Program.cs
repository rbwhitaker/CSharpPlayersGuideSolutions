﻿using System;

Console.WriteLine("Bread is ready.");
Console.WriteLine("Who is the bread for?");
string person = Console.ReadLine();
Console.WriteLine("Noted: " + person + " got bread.");