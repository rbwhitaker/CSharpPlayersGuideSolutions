﻿using System;

Console.WriteLine("The world has changed.");
Console.WriteLine("I feel it in the water.");
Console.WriteLine("I feel it in the earth.");
Console.WriteLine("I smell it in the air.");
Console.WriteLine("Much that once was is lost, for none now live who remember it.");