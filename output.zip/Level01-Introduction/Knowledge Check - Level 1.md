#### 1. True/False. C# is a special-purpose language optimized for a single, specific type of program.

	False. C# is a general-purpose programming language, useful for making most types of programs.

#### 2. What is the name of the framework that C# runs on?

	.NET. (.NET Framework and .NET Core are both correct answers, though .NET Framework is the older
	version, and .NET Core is the old name for the new version.