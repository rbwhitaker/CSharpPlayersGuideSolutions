####1.	What clause (keyword) starts a query expression?

    `from` is the keyword that starts a query expression. It indicates where to pull data from.

####2.	What clause filters data?

    `where` is the keyword/clause that determines which items to keep from a result set.

####3.	True/False. You can order by multiple criteria in a single orderby clause.

    True. By separating the criteria with commas, you can name more than one thing to sort on.

####4.	What clause combines two related sets of data?

    The `join` clause lets you evaluate items from multiple collections together.
