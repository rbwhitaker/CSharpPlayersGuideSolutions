# CSharpPlayersGuideSolutions
My solutions for the challenges in the C# Player's Guide, 4th Edition
