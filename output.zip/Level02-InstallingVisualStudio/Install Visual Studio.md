There is no solution code for this. Just make sure you have an IDE or code editor that you are prepared
to start using installed to claim the points.