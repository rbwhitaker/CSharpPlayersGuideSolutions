#### 1.	Which app model excites you the most and why?

	This is a personal preference, and there is no right answer. The game development ones
	are the most exciting to me naturally, though my employment has been more often in desktop
	and web, with a touch of smartphone development.

#### 2.	Name two desktop UI frameworks in the .NET world.

	There are three: WPF, UWP, and Windows Forms. However, Xamarin Forms will soon be evolving
	into MAUI, which will also target Windows.

#### 3.	What is the name of the extensive library that is available in all C# programs?

	The Base Class Library, or BCL. The book also often refers to this simply as the "standard
	library," which is a more generic name for it. (Nearly all programming languages have
	a standard library, but only .NET languages have the Base Class Library.)

#### 4.	True/False. .NET is limited to only Windows.

	False. The original flavor of .NET, the .NET Framework, was Windows-only. But modern .NET
	supports a wide variety of operating systems, including Windows, Linux, Android, macOS, iOS,
	and more.