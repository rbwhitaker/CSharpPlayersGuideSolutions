#### 1.	What is the name of the feature that provides auto-complete and suggestions as you type? 

	IntelliSense is the name of this feature.

#### 2.	What is the name of the feature that gives you quick fixes and refactorings?

	Quick Actions

#### 3.	Which window shows you all the files in your program?

	The Solution Explorer shows you the high-level view of your whole program, its files, and configuration.

#### 4.	Which window shows you the list of problems currently in your code?

	The Error List.
