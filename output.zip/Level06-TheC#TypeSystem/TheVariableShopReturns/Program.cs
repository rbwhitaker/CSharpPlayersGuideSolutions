﻿using System;

// Declarations and initialization
int a = 3;
uint b = 3;

short c = 3;
ushort d = 3;

long e = 3;
ulong f = 3;

byte g = 3;
sbyte h = 3;

char i = '3';
string j = "3";

bool k = true;

float l = 3.0f;
double m = 3.0;
decimal n = 3.0m;

// Updates
a = 4;
b = 4;
c = 4;
d = 4;
e = 4;
f = 4;
g = 4;
h = 4;
i = '4';
j = "4";
k = false;
l = 4.0f;
m = 4.0;
n = 4.0m;


// Display
Console.WriteLine(a);
Console.WriteLine(b);
Console.WriteLine(c);
Console.WriteLine(d);
Console.WriteLine(e);
Console.WriteLine(f);
Console.WriteLine(g);
Console.WriteLine(h);
Console.WriteLine(i);
Console.WriteLine(j);
Console.WriteLine(k);
Console.WriteLine(l);
Console.WriteLine(m);
Console.WriteLine(n);