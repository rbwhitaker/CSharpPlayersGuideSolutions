﻿namespace TicTacToe
{
    public enum Cell { Empty, X, O }
}
