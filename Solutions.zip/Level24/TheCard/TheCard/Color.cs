﻿namespace TheCard
{
    public enum Color { Red, Green, Blue, Yellow }
}
