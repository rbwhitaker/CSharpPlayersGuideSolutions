﻿namespace TheCard
{
    public enum Rank
    {
        One,
        Two,
        Three,
        Four,
        Five,
        Six,
        Seven,
        Eight,
        Nine,
        Ten,
        DollarSign,
        Percent,
        Caret,
        Ampersand
    }
}
