﻿namespace TheLockedDoor
{
    public enum DoorState { Open, Closed, Locked }
}
